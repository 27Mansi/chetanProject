package com.example.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.example.dto.DtoComplaint;
import com.example.entity.Complaint;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.UserException;
import com.example.repository.CommentRepository;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.UsersRepository;

class TestDepartmentService {
	@InjectMocks
	private DepartmentServiceImpl departmentService;

	@Mock
	private UsersRepository userRepository;

	@Mock
	private DepartmentRepository departmentRepository;

	@Mock
	private ComplaintRepository complaintRepository;
	
	@Mock
	private CommentRepository commentRepository;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetAllComplaints() throws UserException{
		Users user = new Users(11);
		Department dept = new Department(2, "Construction");
		Optional<List<DtoComplaint>> complaints = Optional.of(new ArrayList<>());
		complaints.get().add(new DtoComplaint(101, 11, 2, "PENDING", "Ramesh","Construction", new Date(), 11, 1, "Poor quality of road construction"));
		complaints.get().add(new DtoComplaint(102, 11, 2, "RESOLVED","Ramesh","Construction", new Date(), 11, 1, "Potholes near Pune Railway Station"));

		//mocking JPA methods:
		Mockito.when(userRepository.findByUserEmail("chetanma@cybage.com")).thenReturn(user);
		Mockito.when(departmentRepository.findByUserId(user.getUserId())).thenReturn(dept);
		Mockito.when(complaintRepository.getAllComplaints(2)).thenReturn(complaints.get());
		
		//assertion method:
		assertEquals(2, departmentService.getAllComplaints("chetanma@cybage.com").size());
	}	
	
	@Test
	void testUpdateStatus() throws UserException {
		Users user = new Users(1);
		Department dept = new Department(1, "Construction");
		Optional<Complaint> complaint= Optional.of(new Complaint(101, "Poor quality of road construction", new Date(), "RESOLVED", user, dept));
		complaint.get().setComplaintStatus("RESOLVED");		
		
		//mocking JPA methods:
		Mockito.when(complaintRepository.findById(101)).thenReturn(complaint);
		Mockito.when(complaintRepository.save(complaint.get())).thenReturn(complaint.get());		
		
		//assertion method:
		assertNotNull(departmentService.updateStatus(101, "RESOLVED"));		
	}
	
	@Test
	void TestTransferComplaint() throws UserException{
		Users user = new Users();
		Department dept = new Department();
		Optional<Department> expectedDepartment = Optional.of(new Department());
		Optional<Complaint> complaint= Optional.of(new Complaint(101, "Poor quality of road construction", new Date(), "RESOLVED", user, dept));

		//mocking JPA methods:		
		Mockito.when(complaintRepository.findById(101)).thenReturn(complaint);
		Mockito.when(departmentRepository.findById(2)).thenReturn(expectedDepartment);		
		Mockito.when(complaintRepository.save(complaint.get())).thenReturn(complaint.get());		
		
		//assertion method:
		assertEquals("complaint transferred successfully!", departmentService.transferComplaint(101, 2));		
	}

	@Test
	void testGetComplaintByStatus() {
		List<DtoComplaint> complaints = new ArrayList<DtoComplaint>();
		complaints.add(new DtoComplaint(101, 11, 1, "RESOLVED", "birth", 0, 0, "birth certificate"));
		//mocking JPA methods:
		Mockito.when(complaintRepository.getComplaintReport(1, "RESOLVED")).thenReturn(complaints);
		//assertion method:
		assertEquals(1, complaints.size());
	}
	
	@Test
	void testGetAllDepartments() {
		List<Department> departments = new ArrayList<Department>();
		departments.add(new Department(1, "water"));
		//mocking JPA methods:
		Mockito.when(departmentRepository.findAll()).thenReturn(departments);
		//assertion method:
		assertEquals(1, departments.size());
	}	
	
}