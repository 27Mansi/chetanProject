package com.example.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.example.dto.DtoComment;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoComplaintRegister;
import com.example.entity.Complaint;
import com.example.entity.ComplaintComment;
import com.example.entity.Users;
import com.example.exception.UserException;
import com.example.repository.CommentRepository;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.UsersRepository;

class TestCitizenService {
	 @InjectMocks
	CitizenServiceImpl userService; 
	 
	@Mock
	UsersRepository ur;
	
	@Mock 	
	ComplaintRepository cr;
	
	@Mock 
	DepartmentRepository dr;
	
	@Mock
	CommentRepository commentRepo;
	
	Users user1  = new Users("Amerkhan","amerkhanp@cybage.com",new BCryptPasswordEncoder().encode("1234"),"USER",0,false,false);
	DtoComment commentDto=new DtoComment("amerkhanp@cybage.com",1,"xyz");
	DtoComplaintRegister complaintDto=new DtoComplaintRegister("abc","xyz","amerkhanp@cybage.com",1);
	Complaint complaint=new Complaint();
	
	
	@BeforeEach
	public void init() {
	 MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void citizenRegistrationTest() throws UserException, Exception {
	
	Mockito.when((ur.save(user1))).thenReturn(user1);
	String actual=userService.citizenRegistration(user1);
	assertEquals("citizen registration has been successfully", actual); 
	}
	@Test
    void getAllComplaintsTest() {
           List<DtoComplaint> complaints = new ArrayList<DtoComplaint>();
           complaints.add(new DtoComplaint(101, 11, 1, "PENDING", "Birth Registration", 0, 0, "Birth certificate"));
           List<DtoComplaint> comps = new ArrayList<>(complaints);    
           Mockito.when(cr.getAllComplaints()).thenReturn(comps);
           assertEquals(1, comps.size());
    }
    @Test
    void getComplaintHistoryTest() {
           Users user1  = new Users("Amerkhan","amerkhanp@cybage.com",new BCryptPasswordEncoder().encode("1234"),"USER",0,false,false);
           Mockito.when((ur.save(user1))).thenReturn(user1);
           List<DtoComplaint> complaints = new ArrayList<DtoComplaint>();
           complaints.add(new DtoComplaint(101, 11, 1, "PENDING", "Birth Registration", 0, 0, "Birth certificate"));
           List<DtoComplaint> comps = new ArrayList<>(complaints);    
           Mockito.when(cr.complaintHistory("amerkhanp@cybage.com")).thenReturn(comps);
           assertEquals(1, comps.size());
    }
    @Test
    void getAllCommentsTest() throws UserException {
           List<ComplaintComment> comments=new ArrayList<ComplaintComment>();
           comments.add(new ComplaintComment(1,"Action was delayed", new Users("Amerkhan","amerkhanp@cybage.com",new BCryptPasswordEncoder().encode("1234"),"USER",0,false,false)));
           List<ComplaintComment> commentList = new ArrayList<>(comments);
           Mockito.when(commentRepo.findAll()).thenReturn(commentList);
           assertEquals(1,commentList.size());
    }


}
