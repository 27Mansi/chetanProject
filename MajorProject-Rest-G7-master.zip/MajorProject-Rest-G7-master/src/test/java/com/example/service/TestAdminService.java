package com.example.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Optional;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.example.dto.AddDepartmentDto;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.DeptException;
import com.example.exception.UserException;
import com.example.repository.CommentRepository;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.UsersRepository;

class TestAdminService {
      @InjectMocks
      private AdminServiceImpl adminService;

      @Mock
      private UsersRepository userRepository;

      @Mock
      private DepartmentRepository departmentRepository;

      @Mock
      private ComplaintRepository complaintRepository;
      
      @Mock
      private CommentRepository commentRepository;

      @BeforeEach
      void setUp() throws Exception {
            MockitoAnnotations.openMocks(this);
      }
      @Test
      void getAllDepartmentHeadsTest() {
            List<Users> users = new ArrayList<Users>();
            users.add(new Users("demo", "demo@gmail.com", "demo", "head", 0,false,false));              
            List<Users> heads=new ArrayList<>(users);
            Mockito.when(userRepository.findAll()).thenReturn(users);
            heads=userRepository.findAll();
            assertEquals(1, heads.size());
      }
      
      @Test
      void getAllDepartmentsTest() throws UserException {
            List<Department> departments = new ArrayList<Department>();
            departments.add(new Department(1,"road",new Users("bob", "bob@gmail.com", "bob", "USER", 0,false,false)));                
            List<Department> dept=new ArrayList<>(departments);
            Mockito.when(departmentRepository.findAll()).thenReturn(departments);
            dept=adminService.getAllDepartments();
            assertEquals(1, dept.size());
      }
      @Test
      void addDepartmentHeadTest() throws UserException{
          Users u=new Users("Walt", "Walt@gmail.com", "walt", "head", 0,false,false);
    	  Mockito.when((userRepository.save(u))).thenReturn(u);
    	  Users actual=adminService.addDepartmentHead(u);
    	  assertEquals(actual, u); 
      }
      
      @Test
      void testDeleteDepartment() throws DeptException, UserException {  	  
    	  Users u=new Users("Walt", "Walt@gmail.com", "walt", "head", 0,false,false);
          AddDepartmentDto d=new AddDepartmentDto(u.getUserId(),"heathcare");
          Department dept=new Department(1,"heathcare",u);
          
          Mockito.when((departmentRepository.save(dept))).thenReturn(dept);
          departmentRepository.delete(dept);
          
          assertNull(departmentRepository.findByDeptId(1));
      }
      
      @Test
      void testUpdateDepartment() throws UserException{
      Users u=new Users(1,"Walt", "Walt@gmail.com", "walt", "head", 0,false,false);
      AddDepartmentDto d=new AddDepartmentDto(u.getUserId(),"heathcare");
      Department dept=new Department(1,"heathcare",u);
      Mockito.when((departmentRepository.save(dept))).thenReturn(dept);
      Users u1=new Users(2,"Walter", "Walter@gmail.com", "walter", "head", 0,false,false);
	  dept.setUser(u1);
	  departmentRepository.save(dept);
	  assertEquals(u1,dept.getUser()); 
      }
      
      @Test
      void testDeleteDepartmentHead() throws UserException{
       Optional<Users> user = Optional.of(new Users(1,"Skyler", "skyler@gmail.com", "skyler", "head", 0,false,false));
       
       Mockito.when(userRepository.findById(1)).thenReturn(user);
       Mockito.doNothing().when(userRepository).deleteById(1);
       
       assertEquals("User deleted successfully!", adminService.deleteDepartmentHead(1));
      }
      
}