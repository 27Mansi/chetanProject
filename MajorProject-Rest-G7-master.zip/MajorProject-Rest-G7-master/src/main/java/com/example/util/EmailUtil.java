package com.example.util;

import java.io.InputStream;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailUtil {
	//@Value("${from}")
	private static String from;
	//@Value("${password}")
	private static String password ;
	//@Value("${host}")
	private static String host ;
	
	static {
		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();			
			InputStream is = classloader.getResourceAsStream("application.properties");

			Properties props = new Properties();
			props.load(is);
			from = props.getProperty("from");
			password = props.getProperty("password");
			host = props.getProperty("host");
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	public static String sendEmail(String to,String subject,String text) throws MessagingException {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "25");

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});

		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(to));
		message.setSubject(subject);
		message.setText(text);
		Transport.send(message);
		return "email has been sent successfully";
	}
	
}
