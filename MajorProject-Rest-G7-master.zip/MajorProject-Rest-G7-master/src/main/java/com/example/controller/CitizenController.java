package com.example.controller;

import java.util.List;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.example.dto.ChangePasswordDto;
import com.example.dto.DtoComment;
import com.example.dto.DtoCommentRetrieve;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoComplaintRegister;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.enums.ComplaintStatus;
import com.example.enums.UserRoles;
import com.example.exception.UserException;
import com.example.service.CitizenServiceImpl;

@RestController
@RequestMapping("/citizen")
@CrossOrigin(origins = "*")
public class CitizenController {
	
	public static final Logger logger = LogManager.getLogger(CitizenController.class.getName()); 
	
	@Autowired
	private CitizenServiceImpl citizenService;
	
	//registration of citizen 
	@PostMapping("/register")
	public ResponseEntity<String> citizenRegistration(@RequestBody Users user) throws Exception{
		Users u=new Users(user.getUserName(),user.getUserEmail(),new BCryptPasswordEncoder().encode(user.getUserPass()),UserRoles.USER.toString(),0,false,false);
		  return ResponseEntity.status(HttpStatus.OK).body(citizenService.citizenRegistration(u));
	}
	
	//registration of complaint
	@PreAuthorize("hasRole('USER')")
	@PostMapping("/complaint")
	public ResponseEntity<String> complaintRegistration(@ModelAttribute DtoComplaintRegister complaint,@RequestPart("file") MultipartFile file) throws UserException,Exception{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.complaintRegistration(complaint,file));
	}
	
	//get citizen data by id
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/{id}")
	public ResponseEntity<Users> getCitizen(@PathVariable int id) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.getCitizen(id));
	}
	
	//view all complaints
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/view")
	public ResponseEntity<List<DtoComplaint>> getAllComplaints()throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.getAllComplaints());
	}
	
	//complaint like
	@PreAuthorize("hasRole('USER')")
	@PutMapping("/like")
	public ResponseEntity<String> complaintLike(@RequestBody DtoComment dto) throws UserException {
		//we need to take user id from session storage
		return  ResponseEntity.status(HttpStatus.OK).body(citizenService.complaintLike(dto));
	}

	//complait dislike 
	@PreAuthorize("hasRole('USER')")
	@PutMapping("/dislike")
	public ResponseEntity<String> complaintDislike(@RequestBody DtoComment dto) throws UserException {
		//we need to take user id from session storage
		return   ResponseEntity.status(HttpStatus.OK).body(citizenService.complaintDislike(dto));
	}
	
	//adding comment
	@PreAuthorize("hasRole('USER')")
	@PostMapping("/comment")
	public ResponseEntity<String> addComplaintComment(@RequestBody DtoComment dto) throws UserException {
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.complaintComment(dto));
	}
	
	//view all the comments for particular complaint
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/viewcomments/{compId}")
	public ResponseEntity<List<DtoCommentRetrieve>> getAllComments(@PathVariable int compId) throws UserException{
		return  ResponseEntity.status(HttpStatus.OK).body(citizenService.getAllComments(compId));
	}
	
	//giving reminder to the department head that citizen is not satisfied with head's action
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/complainstatus/{compId}")
	public ResponseEntity<String> changeStatus(@PathVariable int compId) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.changeStatus(compId,ComplaintStatus.REOPENED.toString()));
	}
	
	//get complaint history for a particular citizen
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/complainthistory/{email}")
	public ResponseEntity<List<DtoComplaint>> getComplaintHistory (@PathVariable String email) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.complaintHistory(email));
	}
	
	//getting all departments for a citizen
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/listDept")				
	public ResponseEntity<List<Department>> getAllDepartments() throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.getAllDepartments());
	}
	
	@PostMapping("/forgetpass")
	public ResponseEntity<Integer> forgetPassword(@RequestBody String email) throws MessagingException {
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.forgetPassword(email));
	}
	
	@PostMapping("/verifyotp/{email}")
	public ResponseEntity<Integer> verifyOtp(@RequestBody String otp,@PathVariable String email) throws AddressException, MessagingException {
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.verifyOtp(otp,email));
	}
	
	@PostMapping("/updatepass/{email}")
	public ResponseEntity<Integer> updatePassword(@RequestBody String pass,@PathVariable String email) throws AddressException, MessagingException {
		return ResponseEntity.status(HttpStatus.OK).body(citizenService.updatePassword(pass,email));
	}
	
	@PostMapping("/count/{email}")
	public int countIncrease(@PathVariable String email){
	    return citizenService.increaseCount(email);
	}
	
	@PostMapping("/change")
	public int changePassword(@RequestBody ChangePasswordDto dto){
	    return citizenService.changePassword(dto);
	}
	
	@PostMapping("/unblock/{email}")
	public int unblockAccount(@PathVariable String email){
	    return citizenService.unblockAccountRequest(email);
	}
	
}
