package com.example.controller;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.dto.AddDepartmentDto;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoDeptReport;
import com.example.dto.UpdateDepartmentDto;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.DeptException;
import com.example.exception.UserException;
import com.example.repository.DepartmentRepository;
import com.example.service.AdminServiceImpl;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {
	public static final Logger logger = LogManager.getLogger(AdminController.class.getName()); 
	
	@Autowired
	private AdminServiceImpl adminService;
	@Autowired
	private DepartmentRepository departmentRepository;
	
	//to add a department
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/addDepartment")
	public ResponseEntity<Integer> addDepartment(@RequestBody AddDepartmentDto dto) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.addDepartment(dto));
	}
	
	//To delete department by deptId
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/deleteDept/{deptId}")	
	public ResponseEntity<String> deleteDepartment(@PathVariable int deptId) throws UserException{
		try {
			adminService.deleteDepartment(deptId);
		} catch (DeptException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}		
		return ResponseEntity.status(HttpStatus.OK).body(Integer.toString(deptId));
	}
	
	//To show list of all departments
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/listDept")				
	public ResponseEntity<List<Department>> getAllDepartments() throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.getAllDepartments());
	}
	
	//to get department head by id for update department
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<Users> getHead(@PathVariable int id) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.getHeadById(id));
	}
	
	//to get department details for update
	@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/department/{id}")
    public ResponseEntity<UpdateDepartmentDto> getDepartment(@PathVariable  int id) throws UserException{
           Department d=departmentRepository.findByDeptId(id);
           return ResponseEntity.status(HttpStatus.OK).body(new UpdateDepartmentDto(d.getDeptId(),d.getDeptName(),d.getUser().getUserName(),d.getUser().getUserId()));
	}
	
	//to change deptHead of department
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/upDepartment")
	public ResponseEntity<Integer> updateDepartmentForHead(@RequestBody UpdateDepartmentDto dto) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.upDepartment(dto));
	}
	
	//To show list of all department Head who are not assigned to any department
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/listAllUnassignedDeptHead")				
	public List<Users> getAllUnassignedDeptHead(){
		return adminService.getUnassignedDeptHeads();
	}
	
	//To add a department head
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/deptHeadRegistration")			
	public ResponseEntity<Object> addDepartmentHead(@RequestBody Users user) throws UserException, Exception{
		user.setUserRole("HEAD");
		user.setAccountLocked(false);
		user.setNoOfLoginAttempts(0);
		user.setUnblockedRequest(false);
		adminService.addDepartmentHead(user);		
		return ResponseEntity.status(HttpStatus.CREATED).body(user);		
	}
	
	//To delete department head
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/deleteDeptHead/{userId}")	
	public ResponseEntity<String> deleteDepartmentHead(@PathVariable int userId) throws UserException{		
		adminService.deleteDepartmentHead(userId);
		return ResponseEntity.status(HttpStatus.OK).body(Integer.toString(userId));
	}
	
	//To show list of all departments Head
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/listAllDeptHead")				
	public List<Users> getAllDepartmentsHead(){
		return adminService.getAllDepartmentHeads();
	}
	
	//list of complaints in a department
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/complaints/{deptId}")
	public ResponseEntity<List<DtoComplaint>> getAllComplaints(@PathVariable int deptId) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.getAllComplaints(deptId));
	}
	
	//to get number of complaints in a department 
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/count/{deptId}")
	public ResponseEntity<DtoDeptReport> getcount(@PathVariable int deptId) throws UserException{
		return ResponseEntity.status(HttpStatus.OK).body(adminService.getcount(deptId));
	}
	
	//Generate a report of complaints for a particular department depending on their status
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getComplaintReport/{deptId}/{complaintStatus}")
	public List<DtoComplaint> getComplaintReport(@PathVariable int deptId,@PathVariable String complaintStatus){
		return adminService.getComplaintReport(deptId,complaintStatus);
	}
	
	//To generate overall department report in home page
	@PreAuthorize("hasRole('ADMIN')")	
	@GetMapping("/getDeptReport")			
	public List<DtoDeptReport> getDeptReport(){
		return adminService.getDeptReport();
	}
	
	//show list of accounts that are blocked
	@PreAuthorize("hasRole('ADMIN')")	
	@GetMapping("/blockedaccounts") //getting all blocked accounts 
	public ResponseEntity<List<Users>> listOfBlockAccount(){
		return ResponseEntity.status(HttpStatus.OK).body(adminService.listOfBlockAccount());
	}
	
	//to unblock the account
	@PostMapping("/action/{email}")
	public int unblockAccount(@PathVariable String email){
	    	return adminService.unBlockAccount(email);
	}
	
}