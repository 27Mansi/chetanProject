package com.example;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.example.entity.Users;
import com.example.repository.UsersRepository;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(scanBasePackages = "com.example")
@EnableSwagger2
public class MajarProjectApplication implements CommandLineRunner{
	@Autowired
	UsersRepository ur;
	public static void main(String[] args) {
		SpringApplication.run(MajarProjectApplication.class, args);
	}

	 @Bean
	    public Docket api() {
	        return 
	                new Docket(DocumentationType.SWAGGER_2)
	                .select()
	                .apis(RequestHandlerSelectors.any())    //selecting handler
	                .paths(PathSelectors.any())                //selecting request mapping
	                .build();        
	    }

	@Override
	public void run(String... args) throws Exception {
		
//		Users user1  = new Users("Ameet","ameetn@cybage.com",new BCryptPasswordEncoder().encode("1234"),"USER",0,false,false);
//        ur.save(user1);
//        
//        Users user2  = new Users("Sanjana","sanjanas@cybage.com",new BCryptPasswordEncoder().encode("1234"),"HEAD",0,false,false);
//        ur.save(user2);
//               
//        Users user3  = new Users("Priti","pritidha@cybage.com",new BCryptPasswordEncoder().encode("1234"),"ADMIN",0,false,false);
//        ur.save(user3);     
//        
//        Users user4  = new Users("Aniket","aniket@cybage.com",new BCryptPasswordEncoder().encode("1234"),"HEAD",0,false,false);
//        ur.save(user4);
//        
//        Users user5  = new Users("Vijay","vijay@cybage.com",new BCryptPasswordEncoder().encode("1234"),"HEAD",0,false,false);
//        ur.save(user5);		
	}
}