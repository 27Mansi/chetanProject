package com.example.entity;

import javax.persistence.*;

@Entity
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int deptId;
	
	@Column(length = 25,unique = true,nullable=false)
	private String deptName;

	@OneToOne(fetch = FetchType.EAGER,optional = false,cascade= {CascadeType.MERGE})
	@JoinColumn(name = "userId",nullable = false)
	private Users user;	
	
	public Department() {
		super();		
	}
	
	public Department(int deptId, String deptName, Users user) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.user = user;
	}
	
	public Department(int deptId, String deptName) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;

	}
	
	public Department(String deptName, Users user) {
		super();
		this.deptName = deptName;
		this.user = user;
	}
	
	public int getDeptId() {
		return deptId;
	}
	
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public Users getUser() {
		return user;
	}
	
	public void setUser(Users user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", user=" + user + "]";
	}		
}
