package com.example.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ComplaintComment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int commentId;
	
	@Column(length = 500)
	private String commentDesc;
	
	@ManyToOne(fetch = FetchType.EAGER,
			cascade = CascadeType.ALL,
			targetEntity = Users.class)
	@JoinColumn(name = "userId")
	@JsonIgnore
	private Users user;
	
	public ComplaintComment() {
		super();
	}
	
	public ComplaintComment(String commentDesc, Users user) {
		super();
		this.commentDesc = commentDesc;
		this.user = user;
	}
	
	public ComplaintComment(int commentId, String commentDesc, Users user) {
		super();
		this.commentId = commentId;
		this.commentDesc = commentDesc;
		this.user = user;
	}
	
	public ComplaintComment(int commentId, String commentDesc) {
		super();
		this.commentId = commentId;
		this.commentDesc = commentDesc;
	}
	
	public int getCommentId() {
		return commentId;
	}
	
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	
	public String getCommentDesc() {
		return commentDesc;
	}
	
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}
	
	public Users getUser() {
		return user;
	}
	
	public void setUser(Users user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "ComplaintComment [commentId=" + commentId + ", commentDesc=" + commentDesc ;
	}	
}
