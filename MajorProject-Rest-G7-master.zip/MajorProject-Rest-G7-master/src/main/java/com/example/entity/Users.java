package com.example.entity;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Users {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;	
	
	@Column(length = 25,nullable=false)
	private String userName;
	
	@Column(length = 25,unique = true,nullable=false)
	private String userEmail;
	
	@Column(length = 250,nullable=false)
	private String userPass;
	
	@Column(length = 20,nullable=false)
	private String userRole;
	
	private int noOfLoginAttempts;
	
	private boolean accountLocked;
	
	private boolean unblockedRequest;
	
	@OneToOne(fetch = FetchType.EAGER,mappedBy = "user")
	@JsonIgnore
	private Department department;
	
	public Users() {
		super();		
	}
	
	public Users(int userId, String userName, String userEmail, String userPass, String userRole, int noOfLoginAttempts,
			boolean accountLocked, boolean unblockedRequest) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPass = userPass;
		this.userRole = userRole;
		this.noOfLoginAttempts = noOfLoginAttempts;
		this.accountLocked = accountLocked;
		this.unblockedRequest = unblockedRequest;
	}

	public Users(String userName, String userEmail, String userPass, String userRole, int noOfLoginAttempts,
			boolean accountLocked, boolean unblockedRequest) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPass = userPass;
		this.userRole = userRole;
		this.noOfLoginAttempts = noOfLoginAttempts;
		this.accountLocked = accountLocked;
		this.unblockedRequest = unblockedRequest;
	}

	public boolean isUnblockedRequest() {
		return unblockedRequest;
	}

	public void setUnblockedRequest(boolean unblockedRequest) {
		this.unblockedRequest = unblockedRequest;
	}

	public int getNoOfLoginAttempts() {
		return noOfLoginAttempts;
	}

	public void setNoOfLoginAttempts(int noOfLoginAttempts) {
		this.noOfLoginAttempts = noOfLoginAttempts;
	}

	public Users(int userId) {
		super();
		this.userId=userId;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}

	public boolean isAccountLocked() {
		return accountLocked;
	}

	public void setAccountLocked(boolean accountLocked) {
		this.accountLocked = accountLocked;
	}

	@Override
	public String toString() {
		return "Users [userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ", userPass="
				+ userPass + ", userRole=" + userRole + ", noOfLoginAttempts=" + noOfLoginAttempts + ", accountLocked="
				+ accountLocked + ", unblockedRequest=" + unblockedRequest + "]";
	}	
}
