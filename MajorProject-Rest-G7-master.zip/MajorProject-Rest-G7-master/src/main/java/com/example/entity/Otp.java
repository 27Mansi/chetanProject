package com.example.entity;

import java.time.LocalDateTime;
import javax.persistence.*;

@Entity
public class Otp {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer otpId;
	
	private String otpValue;
	
	private LocalDateTime generatedTime;
	
	private LocalDateTime validTime;
	
	@OneToOne(cascade = CascadeType.REMOVE,fetch = FetchType.EAGER)
	@JoinColumn(name="userId")
	private Users user;
	
	public Otp() {
		super();
	}
	public Otp(String otpValue, LocalDateTime generatedTime, LocalDateTime validTime, Users user) {
		super();
		this.otpValue = otpValue;
		this.generatedTime = generatedTime;
		this.validTime = validTime;
		this.user = user;
	}

	public Otp(Integer otpId, String otpValue, LocalDateTime generatedTime, LocalDateTime validTime, Users user) {
		super();
		this.otpId = otpId;
		this.otpValue = otpValue;
		this.generatedTime = generatedTime;
		this.validTime = validTime;
		this.user = user;
	}

	public LocalDateTime getGeneratedTime() {
		return generatedTime;
	}

	public void setGeneratedTime(LocalDateTime generatedTime) {
		this.generatedTime = generatedTime;
	}


	public LocalDateTime getValidTime() {
		return validTime;
	}

	public void setValidTime(LocalDateTime validTime) {
		this.validTime = validTime;
	}

	public Otp(String otpValue, Users user) {
		super();
		this.otpValue = otpValue;
		this.user = user;
	}

	public Integer getOtpId() {
		return otpId;
	}
	public void setOtpId(Integer otpId) {
		this.otpId = otpId;
	}
	
	public String getOtpValue() {
		return otpValue;
	}

	public void setOtpValue(String otpValue) {
		this.otpValue = otpValue;
	}

	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Otp [otpId=" + otpId + ", otpValue=" + otpValue + ", user=" + user + "]";
	}
	
}
