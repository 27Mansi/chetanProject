package com.example.entity;

import javax.persistence.*;

@Entity
public class LikeDislike {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int likeId; 
	
	private Boolean reaction;

	@ManyToOne(fetch = FetchType.EAGER,
			cascade = CascadeType.ALL,
			targetEntity = Complaint.class)
	@JoinColumn(name = "complaintId")
	private Complaint complaint;
	
	@ManyToOne(fetch = FetchType.EAGER,
			cascade = CascadeType.ALL,
			targetEntity = Users.class)
	@JoinColumn(name = "userId")
	private Users user;
	
	public LikeDislike() {
		super();
	}

	public LikeDislike(int likeId, Boolean reaction, Complaint complaint, Users user) {
		super();
		this.likeId = likeId;
		this.reaction = reaction;
		this.complaint = complaint;
		this.user = user;
	}
	
	public LikeDislike(Boolean reaction, Complaint complaint, Users user) {
		super();
		this.reaction = reaction;
		this.complaint = complaint;
		this.user = user;
	}
	public int getLikeId() {
		return likeId;
	}

	public void setLikeId(int likeId) {
		this.likeId = likeId;
	}
		
	public Boolean getReaction() {
		return reaction;
	}
	public void setReaction(Boolean reaction) {
		this.reaction = reaction;
	}

	public Complaint getComplaint() {
		return complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "LikeDislike [likeId=" + likeId + ", reaction=" + reaction ;
	}		
}
