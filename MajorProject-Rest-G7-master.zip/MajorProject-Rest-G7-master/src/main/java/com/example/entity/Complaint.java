package com.example.entity;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Complaint {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer complaintId;
	
	@Column(length = 500)
	private String complaintDesc;
	
	@Column(length = 500)
	private String remark;
	
	@Column  
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date complaintDate;
	
	@Lob
	private byte[] image;
	
	private String complaintStatus;
	
	private int likeCount;
	
	private int dislikeCount;
	
	@ManyToOne
    @JoinColumn(name="user_id", nullable=false)
	private Users user;
	
	@ManyToOne
    @JoinColumn(name="dept_id", nullable=false)
	private Department department;
	
	@OneToMany(fetch = FetchType.EAGER,
			cascade = CascadeType.ALL)
	@JoinColumn(name = "complaintId")
	private List<ComplaintComment> complaintComment;
	
	public Complaint() {
		super();		
	}
	
	public Complaint(String complaintDesc, String remark, Date complaintDate, String complaintStatus,
			int likeCount, int dislikeCount, Users user, Department department) {
		super();
		this.complaintDesc = complaintDesc;
		this.remark = remark;
		this.complaintDate = complaintDate;
		
		this.complaintStatus = complaintStatus;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.user = user;
		this.department = department;
	}
	
	public Complaint(Integer complaintId, String complaintDesc, Date complaintDate, String complaintStatus, Users user,
			Department department) {
		super();
		this.complaintId = complaintId;
		this.complaintDesc = complaintDesc;
		this.complaintDate = complaintDate;
		this.complaintStatus = complaintStatus;
		this.user = user;
		this.department = department;
	}

	public Complaint(String complaintDesc, String remark, Date complaintDate,String complaintStatus,
			int likeCount, int dislikeCount, Users user, Department department,List<ComplaintComment> complaintComment) {
		super();
		this.complaintDesc = complaintDesc;
		this.remark = remark;
		this.complaintDate = complaintDate;
	
		this.complaintStatus = complaintStatus;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.user = user;
		this.department = department;
		this.complaintComment = complaintComment;
	}
	
	public Complaint(Integer complaintId, String complaintDesc, String remark, Date complaintDate,
			String complaintStatus, int likeCount, int dislikeCount, Users user, Department department,
			List<ComplaintComment> complaintComment) {
		super();
		this.complaintId = complaintId;
		this.complaintDesc = complaintDesc;
		this.remark = remark;
		this.complaintDate = complaintDate;
		this.complaintStatus = complaintStatus;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.user = user;
		this.department = department;
		this.complaintComment = complaintComment;
	}

	public Integer getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintDesc() {
		return complaintDesc;
	}
	
	public Date getComplaintDate() {
		return complaintDate;
	}

	public void setComplaintDate(Date complaintDate) {
		this.complaintDate = complaintDate;
	}

	public void setComplaintDesc(String complaintDesc) {
		this.complaintDesc = complaintDesc;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public int getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<ComplaintComment> getComplaintComment() {
		return complaintComment;
	}

	public void setComplaintComment(List<ComplaintComment> complaintComment) {
		this.complaintComment = complaintComment;
	}

	@Override
	public String toString() {
		return "Complaint [complaintId=" + complaintId + ", complaintDesc=" + complaintDesc + ", remark=" + remark
				+ ", complaintDate=" + complaintDate + ", complaintStatus=" + complaintStatus + ", likeCount="
				+ likeCount + ", dislikeCount=" + dislikeCount + ", user=" + user + ", department=" + department
				+ ", complaintComment=" + complaintComment + "]";
	}			
}
