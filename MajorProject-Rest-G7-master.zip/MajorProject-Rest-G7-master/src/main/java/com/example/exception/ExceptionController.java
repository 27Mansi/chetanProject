package com.example.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {
	public static final Logger logger = LogManager.getLogger(ExceptionController.class); 
	@ExceptionHandler(UserException.class)
	@ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
	public String handleException(UserException ue)
	{
		logger.error(ue.getMessage());
		return ue.getMessage();
	}	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(code = HttpStatus.SEE_OTHER)
	public String handleException(Exception ue)
	{
		logger.error(ue.getMessage());
		return ue.getMessage();
	}
}
