package com.example.exception;

public class DeptException extends Exception{
	private static final long serialVersionUID = 1L;
	public DeptException(String msg) {
		super(msg);
	}
}
