package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entity.Otp;
import com.example.entity.Users;

public interface OtpRepository extends JpaRepository<Otp, Integer> {
	public Otp findByUser(Users user);

}
