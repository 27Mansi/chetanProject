package com.example.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.dto.DtoDeptReport;
import com.example.entity.Department;
import com.example.entity.Users;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer>{
	
	@Query(value = "select s from Users s where s.userId=?1",nativeQuery = false)
	public Users getSpecificUser(int id);
	
	@Query(value = "select d from Department d")
	public List<Department> getAllDepartment();
	
	@Query(value = "select d from Department d where d.deptId=?1",nativeQuery = false)
	public Department getdept(int id);	
	
	@Query(value = "select new com.example.dto.DtoDeptReport(d.deptId, d.deptName,d.user.userName,"
			+"cast(count(d.deptId) as int),cast(sum(case when c.complaintStatus = 'RESOLVED' then 1 else 0 end)as int) AS ResolveCount, "
			+"cast(sum(case when c.complaintStatus = 'PENDING' then 1 else 0 end)as int) AS pendingount, "
			+"cast(sum(case when c.complaintStatus = 'REOPENED' then 1 else 0 end)as int) AS reopenedCount) "
			+"from Complaint c join c.department d group by d.deptId",nativeQuery = false)
	public List<DtoDeptReport> getDeptReport();
	
	@Query(value = "select new com.example.dto.DtoDeptReport(d.deptId, d.deptName,d.user.userName,"
			+"cast(count(d.deptId) as int),cast(sum(case when c.complaintStatus = 'RESOLVED' then 1 else 0 end)as int) AS ResolveCount, "
			+"cast(sum(case when c.complaintStatus = 'PENDING' then 1 else 0 end)as int) AS pendingcount, "
			+"cast(sum(case when c.complaintStatus = 'REOPENED' then 1 else 0 end)as int) AS reopenedCount) "
			+"from Complaint c join c.department d where d.deptId=?1 group by d.deptId",nativeQuery = false)
	public DtoDeptReport getCount(int deptId);
	
	@Query(value="select d from Department d join d.user u where d.user.userId=?1",nativeQuery = false)
	public Department findByUserId(int userId);
	
	public Department findByDeptId(int id);
}
