package com.example.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.dto.DtoComplaint;
import com.example.entity.Complaint;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Integer>{

	//query to get list of all complaints
	@Query(value ="select new com.example.dto.DtoComplaint(c.complaintId,u.userId,d.deptId,c.complaintStatus,u.userName,d.deptName,"
			+ "c.complaintDate,c.likeCount,c.dislikeCount,c.complaintDesc) from Complaint c "
			+ "join c.user u join c.department d",nativeQuery = false)
	public List<DtoComplaint> getAllComplaints();

	//query to get list of complaints by department id
	@Query(value = "select new com.example.dto.DtoComplaint(c.complaintId,u.userId,d.deptId,c.complaintStatus,u.userName,d.deptName,"
			+ "c.complaintDate,c.likeCount,c.dislikeCount,c.complaintDesc) from Complaint c "
			+ "join c.user u join c.department d where c.department.deptId=?1",nativeQuery = false)
	public List<DtoComplaint> getAllComplaints(int deptId);

	//query to get list of complaint by user id
	@Query(value = "select new com.example.dto.DtoComplaint(c.complaintId,u.userId,d.deptId,c.complaintStatus,u.userName,d.deptName,"
			+ "c.complaintDate,c.likeCount,c.dislikeCount,c.complaintDesc) from Complaint c "
			+ "join c.user u join c.department d where c.user.userEmail=?1",nativeQuery = false)
	public List<DtoComplaint> complaintHistory(String email);

	//query to get complaint report by department id and complaint status
	@Query(value = "select new com.example.dto.DtoComplaint(d.deptId, d.deptName,d.user.userName, c.complaintId, u.userId, u.userName,c.complaintDesc,"
			+ "c.complaintStatus, c.complaintDate,c.likeCount,c.dislikeCount) from Complaint c"
			+ " join c.user u join c.department d where c.department.deptId=?1 and c.complaintStatus=?2",nativeQuery = false)
	public List<DtoComplaint> getComplaintReport(int deptId,String complaintStatus);

	

}
