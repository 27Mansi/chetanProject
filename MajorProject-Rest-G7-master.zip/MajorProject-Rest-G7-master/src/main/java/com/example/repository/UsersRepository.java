package com.example.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.entity.Users;

@Repository
@Transactional
public interface UsersRepository extends JpaRepository<Users, Integer>{
	
	@Query(value = "select s from Users s where s.userId=?1",nativeQuery = false)
	public Users getSpecificUser(int id);
	
	@Query(value = "select s from Users s where s.userEmail=?1",nativeQuery = false)
	public Users getSpecificUserByEmail(String userEmail);
	
	@Query(value = "select s from Users s where s.userRole='HEAD'",nativeQuery = false)
	public List<Users> getAllDepartmentHead();	
	
	public Users findByUserEmail(String userEmail);
	
	@Query(value = "select u from Users u where u.accountLocked=true and u.unblockedRequest=true",nativeQuery = false)
	public List<Users> getAllBlockedAccounts();
	
	@Query(value="select u from Users u "
			+ "where u.userId NOT IN (select d.user.userId from Department d) and userRole='HEAD'",nativeQuery = false)
	public List<Users> getAllUnassignedDeptHeads();
	
}
