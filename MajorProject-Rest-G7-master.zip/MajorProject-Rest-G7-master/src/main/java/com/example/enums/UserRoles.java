package com.example.enums;

public enum UserRoles {
	USER,
	HEAD,
	ADMIN
}