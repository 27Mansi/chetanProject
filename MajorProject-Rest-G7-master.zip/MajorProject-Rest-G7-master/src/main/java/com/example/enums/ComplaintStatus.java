package com.example.enums;

public enum ComplaintStatus {
	RESOLVED,
	REOPENED,
	PENDING
}