package com.example.service;

import java.util.List;
import javax.mail.MessagingException;
import com.example.dto.AddDepartmentDto;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoDeptReport;
import com.example.dto.UpdateDepartmentDto;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.DeptException;
import com.example.exception.UserException;

public interface AdminI {
	
	public String deleteDepartment(int deptId) throws DeptException, UserException;
	
	public List<Department> getAllDepartments()throws UserException;
	
	public Users addDepartmentHead(Users user) throws UserException, MessagingException;
	
	public String deleteDepartmentHead(int userId) throws UserException;
	
	public List<Users> getAllDepartmentHeads();	
	
	public List<DtoDeptReport> getDeptReport();
	
	public List<DtoComplaint> getComplaintReport(int deptId,String complaintStatus);
	
	public List<Users> listOfBlockAccount();
	
	public int unBlockAccount(String email);
	
	public List<Users> getUnassignedDeptHeads();
	
	public Users getHeadById(int id) throws UserException ;
	
	public int addDepartment(AddDepartmentDto dto) throws UserException;
	
	public int upDepartment(UpdateDepartmentDto dto) throws UserException;
	
	public List<DtoComplaint> getAllComplaints(int deptId) throws UserException;
	
	public DtoDeptReport getcount(int deptId) throws UserException;


}