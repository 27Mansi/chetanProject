package com.example.service;

import java.util.List;
import java.util.Optional;
import javax.mail.MessagingException;
import javax.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.dto.AddDepartmentDto;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoDeptReport;
import com.example.dto.UpdateDepartmentDto;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.DeptException;
import com.example.exception.UserException;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.UsersRepository;
import com.example.util.EmailUtil;


@Service
@Transactional
public class AdminServiceImpl implements AdminI {

	public static final Logger logger = LogManager.getLogger(AdminServiceImpl.class.getName());
	@Autowired
	UsersRepository userRepository;

	@Autowired
	DepartmentRepository deptRepository;

	@Autowired
	ComplaintRepository complaintRepository;

	@Override
	public String deleteDepartment(int deptId) throws DeptException, UserException{
		
		if(!(deptRepository.findAll().stream().anyMatch(d->d.getDeptId()==deptId))) {
			logger.error (()->"Department deletion failed, department with deptId:"+deptId+ "not found");
			throw new DeptException("Department not found, please check the deptId and try again");
		}

		Boolean check=complaintRepository.findAll().stream().anyMatch(c->(c.getDepartment().getDeptId()==deptId)&&(!c.getComplaintStatus().equals("RESOLVED")));		
		if(Boolean.FALSE.equals(check)) {
			
			List<DtoComplaint> complaints = complaintRepository.getComplaintReport(deptId, "RESOLVED");
			
			complaints.forEach(c->complaintRepository.deleteById(c.getComplaintId()));
			deptRepository.deleteById(deptId);			
			logger.info(()->"Deleted department with deptId:"+deptId);
			return Integer.toString(deptId)+"dept has been deleted";								
		}else {
			logger.error (()->"Department deletion failed, resolved complaints before deleting department");
			throw new UserException("Please resolve complaints in the department before closing the department.");		
		}			
	}

	@Override
	public List<Department> getAllDepartments() throws UserException{
		
		List<Department> departments = deptRepository.findAll();
		if(departments.isEmpty())
			throw new UserException("No departments found!");
		else 
			return departments;
	}

	@Override
	public Users addDepartmentHead(Users user) throws UserException {
		
				String subject="Account Credentials";
				String text="Username: "+user.getUserEmail()+"\nPassword: "+user.getUserPass();
				try {
					
					EmailUtil.sendEmail(user.getUserEmail(), subject,text);
					
				} catch (MessagingException e) {
					logger.error (()->"Head registration failed,wrong email address");
					throw new UserException("Please check email address!!!");
				} 
				
		user.setUserRole("HEAD");
		user.setUserPass(new BCryptPasswordEncoder().encode(user.getUserPass()));
		logger.info(()->"Department head registered with userId:"+user.getUserId());
		return userRepository.save(user);
	}

	public String deleteDepartmentHead(int userId)  throws UserException{
		
		Optional<Users> user = Optional.ofNullable(userRepository.findById(userId)).get();
		if(user.isEmpty()) {
			logger.error (()->"Head deletion failed,user with userId:"+userId+"not found");
			throw new UserException("No user found to delete!");
		}
		else {
			userRepository.deleteById(userId);
			logger.info(()->"Department head with userId:"+userId+" deleted");
			return "User deleted successfully!";
		}
	}

	@Override
	public List<Users> getAllDepartmentHeads() {		
		return userRepository.getAllDepartmentHead();
	}

	@Override
	public List<DtoDeptReport> getDeptReport(){
		return deptRepository.getDeptReport();
	}

	@Override
	public List<DtoComplaint> getComplaintReport(int deptId,String complaintStatus) {
		return complaintRepository.getComplaintReport(deptId,complaintStatus);
	}

	@Override
	public List<Users> listOfBlockAccount() {	
		return userRepository.getAllBlockedAccounts();
	}

	@Override
	public int unBlockAccount(String email) {
		Users user=userRepository.findByUserEmail(email);
		user.setAccountLocked(false);
		user.setNoOfLoginAttempts(0);
		user.setUnblockedRequest(false);
		userRepository.save(user);
		logger.info(()->"Account unblocked,userId:"+user.getUserId());
		return 1;
	}

	@Override
	public List<Users> getUnassignedDeptHeads() {		
		return userRepository.getAllUnassignedDeptHeads();
	}
	
	@Override
	public Users getHeadById(int id) throws UserException {
		//getting specific user
		Optional<Users> user=userRepository.findById(id);
		if(user.isEmpty())
			throw new UserException("Please enter valid user Id");
		else
			return user.get();
	}

	@Override
	public int addDepartment(AddDepartmentDto dto) throws UserException {
		Users u=userRepository.getSpecificUser(dto.getUserId());
		Department dept=new Department(dto.getDeptName(),u);
		deptRepository.save(dept);
		logger.info(()->dto.getDeptName()+" Department added");
		return 1;
	}
	
	@Override
	public int upDepartment(UpdateDepartmentDto dto) throws UserException {
		Users u=userRepository.getSpecificUser(dto.getUserId());	
		Department dept=deptRepository.findByDeptId(dto.getDeptId());
		dept.setUser(u);
		deptRepository.save(dept);
		logger.info(()->"Department with deptId:"+dto.getDeptId()+"updated");
		return 1;		
	} 
	
	public List<DtoComplaint> getAllComplaints(int deptId) throws UserException {
		return complaintRepository.getAllComplaints(deptId);
	}

	@Override
	public DtoDeptReport getcount(int deptId) throws UserException {
		return deptRepository.getCount(deptId);
	} 

}