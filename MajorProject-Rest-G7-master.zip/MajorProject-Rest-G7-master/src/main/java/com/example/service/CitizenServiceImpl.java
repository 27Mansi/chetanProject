package com.example.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.example.dto.ChangePasswordDto;
import com.example.dto.DtoComment;
import com.example.dto.DtoCommentRetrieve;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoComplaintRegister;
import com.example.entity.Complaint;
import com.example.entity.ComplaintComment;
import com.example.entity.Department;
import com.example.entity.LikeDislike;
import com.example.entity.Otp;
import com.example.entity.Users;
import com.example.enums.ComplaintStatus;
import com.example.exception.UserException;
import com.example.repository.CommentRepository;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.LikeDislikeRepository;
import com.example.repository.OtpRepository;
import com.example.repository.UsersRepository;
import com.example.util.EmailUtil;

@Service
@Transactional
@Component
public class CitizenServiceImpl implements CitizenI{
	
	public static final Logger logger = LogManager.getLogger(CitizenServiceImpl.class.getName());
	
	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LikeDislikeRepository likeDislikeRepository;
	
	@Autowired 
	ComplaintRepository complaintRepository;
	
	@Autowired
	private CommentRepository commentRepository;
	
	@Autowired
	private DepartmentRepository dr;
	
	@Autowired
	private OtpRepository otpRepository;
	
	public String citizenRegistration( Users user) throws Exception{
		
		//adding user in database		
			Users u=usersRepository.save(user);
			EmailUtil.sendEmail(user.getUserEmail(),"Registration information" , "username: "+user.getUserEmail()+" You have created account to our portal");
			logger.info(()->"Citizen added ,userId "+u.getUserId());
			return "citizen registration has been successfully";					
	}
	
	//Complaint Registration by citizen -------San
	public String complaintRegistration(DtoComplaintRegister dto,MultipartFile file)  throws Exception{
		//Check if the complaint object received is null 
		if(dto!=null && file!=null) {
			//If the object received is not null then proceed to register
			//extract  the department and user id
			int departmentId=dto.getDeptId();		
			//proceed to create the object for new complaint
			Complaint comp=new Complaint(dto.getComplaintDesc(),dto.getRemark(),new Date(),ComplaintStatus.PENDING.toString(),0,0,usersRepository.findByUserEmail(dto.getUserEmailDto()),dr.getdept(departmentId));
			//set the image for the new complaint 
			comp.setImage(file.getBytes());
			//Insert the new complaint in database
			complaintRepository.save(comp);
			//In logger it will be mentioned if the citizen registers a complaint
			logger.info( ()-> "New Complaint registered by user %s"+comp.getUser());
			
			//Return the complaint status to the User
			return  "New Complaint registered for user";
		}
		else {
			//If the object received is null
			logger.error ("Complaint registration failed");
			throw new UserException("Complaint registration failed ");
			}
	}
	
	public Users getCitizen(int id) throws UserException{
		//getting specific user
		Optional<Users> user=usersRepository.findById(id);
		if(user.isEmpty())
			throw new UserException("Please enter valid user Id");
		else
			return user.get();	
	}
	
	@Override
	public List<DtoComplaint> getAllComplaints() throws UserException {
		return complaintRepository.getAllComplaints();
	}
	
	public String complaintLike(DtoComment dto) throws UserException{
		
		//getting all the like dislike data 
		List<LikeDislike> list=likeDislikeRepository.findAll();
		Users u=usersRepository.findByUserEmail(dto.getUserEmailDto());
		int userId=u.getUserId();
		int complaintId=dto.getComplaintIdDto();
		//here we r using stream api (java-8 feature) for iteration
		Optional<LikeDislike> likeDislike=list
		.stream()
		.filter(l->(l.getUser().getUserId()==userId && l.getComplaint().getComplaintId()==complaintId)).findFirst();
		
		//fetching complaint object from database for particular complaint id
		Complaint complaint=complaintRepository.getOne(complaintId);
		//checking if user like that particular complaint or not
		if(likeDislike.isEmpty()) {//block will get unlock if particular user doesont like that post yet
			
			complaint.setLikeCount(complaint.getLikeCount()+1);//increasing like count by 1
			complaintRepository.save(complaint); //updating complaint object in dataabase (detached->persist)
			likeDislikeRepository.save(new LikeDislike(true,complaintRepository.getOne(complaintId),usersRepository.getOne(userId)));//updating like dislike entity/table also
			logger.info(()->"complaint has been liked by user Id"+userId+"   "+complaintId);
			return "You have liked complaint with complaint Id "+complaintId;
			
		}
		else {
			if(likeDislike.get().getReaction()) {//block will get unlock weather if user have already liked that complaint
				logger.info(()->"complaint has been liked by user Id"+userId+"   "+complaintId);
				return "You have already liked complaint with complaint Id "+complaintId;
			}
			else {//block will get unlock if user have already disliked the comolaint and now he wants to liked that apecific complaint
				//we r increasing count of liked 
				complaint.setLikeCount(complaint.getLikeCount()+1);
				//here we r decreasing the dislike count 
				complaint.setDislikeCount(complaint.getDislikeCount()-1);
				//detached making that object persist
				complaintRepository.save(complaint);
				//setting reaction status
				likeDislike.get().setReaction(true);
				//setting updated complaint
				likeDislike.get().setComplaint(complaint);
				//finally making that likeDislike object to persist
				likeDislikeRepository.save(likeDislike.get());
				logger.info(()->"complaint has been liked by user Id"+userId+"   "+complaintId);
				return "You were dis-liked,now you have liked this complaint  with complaint Id "+complaintId;
			}
		}		
	}
	
	public String complaintDislike(DtoComment dto) throws UserException{
		
		//getting all the like dislike data 
		List<LikeDislike> list=likeDislikeRepository.findAll();
		Users u=usersRepository.findByUserEmail(dto.getUserEmailDto());
		int userId=u.getUserId();
		int complaintId=dto.getComplaintIdDto();
		//here we r using stream api (java-8 feature) for iteration
		Optional<LikeDislike> likeDislike=list
		.stream()
		.filter(l->(l.getUser().getUserId()==userId && l.getComplaint().getComplaintId()==complaintId)).findFirst();
		
		//fetching complaint object from database for particular complaint id
		Complaint complaint=complaintRepository.getOne(complaintId);
		//checking if user dis-like that particular complaint or not
		if(likeDislike.isEmpty()) {//block will get unlock if particular user doesont dislike/like that post yet
			
			complaint.setDislikeCount(complaint.getDislikeCount()+1);//increasing like count by 1
			
			complaintRepository.save(complaint); //updating complaint object in dataabase (detached->persist)
			likeDislikeRepository.save(new LikeDislike(false,complaintRepository.getOne(complaintId),usersRepository.getOne(userId)));//updating like dislike entity/table also
			logger.info(()->"complaint has been Dis liked by user Id"+userId+"   "+complaintId);
			return "You have dis-liked complaint with complaint Id "+complaintId;
			
		}
		else {
			if(!likeDislike.get().getReaction()) {//block will get unlock weather if user have already liked that complaint
				logger.info(()->"complaint has been Dis liked by user Id"+userId+"   "+complaintId);
				return "You have already dis-liked complaint with complaint Id "+complaintId;
			}
			else {//block will get unlock if user have already liked the comolaint and now he wants to Dis-liked that apecific complaint
				//we r increasing count of Dis-liked 
				complaint.setDislikeCount((complaint.getDislikeCount()+1));
				//here we r decreasing the like count 
				complaint.setLikeCount(complaint.getLikeCount()-1);
				//detached making that object persist
				complaintRepository.save(complaint);
				//setting reaction status
				likeDislike.get().setReaction(false);
				//setting updated complaint
				likeDislike.get().setComplaint(complaint);
				//finally making that likeDislike object to persist
				likeDislikeRepository.save(likeDislike.get());
				logger.info(()->"complaint has been Dis-liked by user Id"+userId+"   "+complaintId);
				return "You were liked,now you have dis-liked this complaint  with complaint Id "+complaintId;
			}
		}		
	}
	
	public String complaintComment(DtoComment dto) throws UserException{
		
		//here i am getting particular complaint 
		Complaint complaint=complaintRepository.getOne(dto.getComplaintIdDto());
		//here i m creating object of comment
		Users u=usersRepository.findByUserEmail(dto.getUserEmailDto());
		ComplaintComment comment=new ComplaintComment(dto.getDescDto(),u);
		//here i m adding comment in list
		complaint.getComplaintComment().add(comment);
		//finally i m saving comment in Complaint table 
		try {
			ComplaintComment cc=commentRepository.save(comment);
			complaint.getComplaintComment().add(cc);
			logger.info(()->"Comment has been updated of complain with complain Id "+dto.getComplaintIdDto());
			return "Comment has been updated of complain with complain Id "+dto.getComplaintIdDto();
		} catch (Exception e) {
			throw new UserException("user id or complaint id is invalid");
		}
	}
	
	//getting all comments related to complaint id
	public List<DtoCommentRetrieve> getAllComments(int compId) throws UserException{		
		 List<Complaint> list=complaintRepository.findAll();
		 Optional<Complaint> comp1=
				 					list
				 					.stream()
				 					.filter(l->(l.getComplaintId()==compId)).findFirst();
		 if(comp1.isEmpty())
			 throw new UserException("There is not a complaint with comp Id "+compId);
		 
		 Complaint comp2=comp1.get();
		 List<ComplaintComment> list1=comp2.getComplaintComment();
		 List<DtoCommentRetrieve> list2=new ArrayList<>();		
		 for(ComplaintComment itr:list1) {
			 list2.add(new DtoCommentRetrieve(itr.getCommentId(),itr.getCommentDesc(),itr.getUser().getUserId(),itr.getUser().getUserName()));
		 }
		
		 return list2;
	}
	
	//Citizen can give reminder for particular complaint
	@Override
	public String changeStatus(int compId, String status) throws UserException{
		Complaint complaint=complaintRepository.getOne(compId);
		if(complaint.getComplaintStatus().equals(ComplaintStatus.PENDING.toString()) || complaint.getComplaintStatus().equals(ComplaintStatus.RESOLVED.toString())) {
		complaint.setComplaintStatus(status);
		complaint.setComplaintDate(new Date());
		complaintRepository.save(complaint);
		logger.info(()->"Reminder has been given to the dapartment with complaint id "+compId);
		}
		return "Reminder has been given to the dapartment";
	}
	
	@Override
	public List<DtoComplaint> complaintHistory(String email) throws UserException {
		return complaintRepository.complaintHistory(email);
	}
	
	public List<Department> getAllDepartments() throws UserException{
		return dr.findAll();
	}
	
	// forget password
	@Override
	public int forgetPassword(String email) throws AddressException, MessagingException {
		// getting user
		Users user=usersRepository.findByUserEmail(email);
		if(user!=null){
			String otpValue= ""+Math.round(Math.random()*10000);
			Otp otpentity=otpRepository.findByUser(user);
			if(otpentity!=null) {
				Otp otp = new Otp(otpentity.getOtpId(),otpValue,LocalDateTime.now(),LocalDateTime.now().plusMinutes(30), user);
				EmailUtil.sendEmail(email, "verify otp",otpValue);
				logger.info(()->"password has been changed with email id "+email);
				otpRepository.save(otp);
				return 1;
			}
			else {
				Otp otp = new Otp(otpValue,LocalDateTime.now(),LocalDateTime.now().plusMinutes(30), user);
				EmailUtil.sendEmail(email, "verify otp","Your otp is "+otpValue +".It will be valid for next 30 minutes");
				otpRepository.save(otp);
				logger.info(()->"password has been changed with email id "+email);
				return 1;
			}
			
		}else {
			// message to user not valid user
			return 0;
		}
	}
	
	// VERIFY OTP
	@Override
	public int verifyOtp(String otp, String email) {
		
		Users user=usersRepository.findByUserEmail(email);
		Otp otpentity=otpRepository.findByUser(user);
		if(otpentity.getValidTime().isAfter(LocalDateTime.now())) {
			if(otpentity.getOtpValue().equals(otp)) {
				return 1;//otp verified
			}
			else
				return 2;//invalid otp
		}
		else
			return 0;//otp expired
	}

	@Override
	public int updatePassword(String pass, String email) {
		
		Users user=usersRepository.findByUserEmail(email);
		user.setUserPass(new BCryptPasswordEncoder().encode(pass));
		usersRepository.save(user);
		return 1;
	}
	
	@Override
	public int changePassword(ChangePasswordDto dto) {
		
		Users user=usersRepository.findByUserEmail(dto.getUserEmailDto());
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		
		if(passwordEncoder.matches(dto.getCurrentPass(), user.getUserPass())) {
			user.setUserPass(new BCryptPasswordEncoder().encode(dto.getNewPass()));
			usersRepository.save(user);
			logger.info(()->"password has been chenged with email id "+dto.getUserEmailDto());
			return 1;
		}
		return 0;
	}
	
	@Override
	public int increaseCount(String email) {
		
		Users user=usersRepository.findByUserEmail(email);
		user.setNoOfLoginAttempts(user.getNoOfLoginAttempts()+1);//count increased after logged in with wrong credentials
		usersRepository.save(user);
		return user.getNoOfLoginAttempts();
	}
	
	@Override
	public int unblockAccountRequest(String email) {

		Users user=usersRepository.findByUserEmail(email);
		if(user!=null) {
			if(user.isAccountLocked() && !user.isUnblockedRequest()) {
				user.setUnblockedRequest(true);
				usersRepository.save(user);
				logger.info(()->"Request has been registered for unblocking account with email id "+email);
				return 1;//request has been registered
			}
			else
				return 0;//either account is not yet locked or u have registered unblock request
		}
		else	
			return 2;		
	}
	
}
