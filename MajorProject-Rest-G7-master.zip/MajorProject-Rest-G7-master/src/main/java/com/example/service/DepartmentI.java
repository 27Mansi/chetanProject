package com.example.service;

import java.util.HashMap;
import java.util.List;
import com.example.dto.DtoComplaint;
import com.example.entity.Complaint;
import com.example.entity.Department;
import com.example.exception.UserException;

//method's declaration
public interface DepartmentI {
	
	public List<DtoComplaint> getAllComplaints(String userEmail) throws UserException;
	
	public HashMap<String, String> updateStatus(int complaintId, String complaintStatus) throws UserException;
	
	public String transferComplaint(int complaintId, int deptId) throws UserException;	
	
	public List<DtoComplaint> getComplaintsByStatus(String userEmail, String status) throws UserException;
	
	public List<Department> getAllDepartments() throws UserException;
	
}