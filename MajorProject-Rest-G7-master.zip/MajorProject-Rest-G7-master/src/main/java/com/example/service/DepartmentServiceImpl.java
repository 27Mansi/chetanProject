package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.dto.DtoComplaint;
import com.example.entity.Complaint;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.enums.ExceptionMessages;
import com.example.exception.UserException;
import com.example.repository.ComplaintRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.UsersRepository;

@Service
public class DepartmentServiceImpl implements DepartmentI{
	
	@Autowired
	DepartmentRepository deptRepo;
	
	@Autowired
	ComplaintRepository complaintRepo;
	
	@Autowired
	UsersRepository userRepo;
	
	public static final Logger logger = LogManager.getLogger(DepartmentServiceImpl.class.getName());
	
	//method to display all complaints of specific department
	@Override
	public List<DtoComplaint> getAllComplaints(String userEmail) throws UserException{		
		//getting user(deptHead) object
		Optional<Users> deptHead = Optional.ofNullable(userRepo.findByUserEmail(userEmail));
		if(deptHead.isEmpty())
			throw new UserException(ExceptionMessages.DEPARTMENTHEAD_NOT_FOUND.toString());
		
		//getting department object									//deptHead.get().getUserId()
		Optional<Department> dept = Optional.ofNullable(deptRepo.findByUserId(deptHead.get().getUserId()));
		if(dept.isEmpty())
			throw new UserException(ExceptionMessages.NO_SUCH_DEPARTMENT_FOUND.toString());
		
		//getting list of complaints
		Optional<List<DtoComplaint>> complaint = Optional.ofNullable(complaintRepo.getAllComplaints(dept.get().getDeptId()));
		if(complaint.isEmpty())
			throw new UserException(ExceptionMessages.NO_COMPLAINTS_FOUND.toString());
		return complaint.get();	
	}
	
	//method to change status of a complaint
	@Override
	public HashMap<String, String> updateStatus(int complaintId, String complaintStatus) throws UserException {
		HashMap<String, String> hmap = new HashMap<>();
		//getting complaint object
		Optional<Complaint> complaint = Optional.ofNullable(complaintRepo.findById(complaintId)).get();
		if(complaint.isEmpty()) {
			logger.error(()->"Updation of complaint "+complaintId+" failed as there is no such comment");
			throw new UserException(ExceptionMessages.NO_SUCH_COMPLAINT_FOUND.toString());
		}	
		complaint.get().setComplaintStatus(complaintStatus);		//update complaintStatus
		complaintRepo.save(complaint.get());
		hmap.put("msg", "Complaint resolved successfully!");
		logger.info(()->"Complaint with complaintId:"+complaintId+" updated");
		return hmap;		
	}  
	
	//Transfer complaint to another department
	@Override
	public String transferComplaint(int complaintId, int deptId) throws UserException {
		//getting complaint object
		Optional<Complaint> complaint = Optional.ofNullable(complaintRepo.findById(complaintId)).get();		
		if(complaint.isEmpty()) {
			logger.error(()->"Transfer of complaint "+complaintId+" failed as there is no such comment");
			throw new UserException(ExceptionMessages.NO_SUCH_COMPLAINT_FOUND.toString());
		}
		
		//getting department object
		Optional<Department> department = Optional.ofNullable(deptRepo.findById(deptId)).get();			
		if(department.isEmpty()) {
			logger.error(()->"Tranfer of complaint "+complaintId+" failed as there is no such department");
			throw new UserException(ExceptionMessages.NO_SUCH_DEPARTMENT_FOUND.toString());
		}
		
		department.get().setDeptId(deptId);
		complaint.get().setDepartment(department.get());
		complaintRepo.save(complaint.get());
		logger.info(()->"Complaint with complaintId:"+complaintId+" transferred to"+department.get().getDeptId()+"department");//update departmentId
		return "complaint transferred successfully!";												
	}	
	
	//Get all complaints' list according to status
	public List<DtoComplaint> getComplaintsByStatus(String userEmail, String complaintStatus) throws UserException {
		//getting user(deptHead) object
		Optional<Users> deptHead = Optional.ofNullable(userRepo.findByUserEmail(userEmail));	
		if(deptHead.isEmpty())
			throw new UserException(ExceptionMessages.DEPARTMENTHEAD_NOT_FOUND.toString());
		
		//getting list of complaints
		List<DtoComplaint> complaints = complaintRepo.getComplaintReport(deptHead.get().getDepartment().getDeptId(),complaintStatus);
		if(complaints.isEmpty())
			throw new UserException(ExceptionMessages.NO_COMPLAINTS_FOUND.toString());
 
		return complaints;
	}

	//Get all department list
	@Override
	public List<Department> getAllDepartments() throws UserException {
		Optional<List<Department>> departments = Optional.ofNullable(deptRepo.getAllDepartment());
		if(departments.isEmpty())
			throw new UserException(ExceptionMessages.NO_DEPARTMENTS_FOUND.toString());
		
		return departments.get();
	}

}