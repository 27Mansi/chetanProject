package com.example.service;

import java.util.List;
import javax.mail.MessagingException;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.example.dto.ChangePasswordDto;
import com.example.dto.DtoComment;
import com.example.dto.DtoCommentRetrieve;
import com.example.dto.DtoComplaint;
import com.example.dto.DtoComplaintRegister;
import com.example.entity.Department;
import com.example.entity.Users;
import com.example.exception.UserException;

public interface CitizenI {
	
	public String citizenRegistration( Users user) throws Exception;
	
	public String complaintRegistration(DtoComplaintRegister complaint,MultipartFile file)  throws Exception;
	
	public Users getCitizen(int id) throws UserException;
	
	public String complaintLike(DtoComment dto) throws UserException;
	
	public String complaintDislike(DtoComment dto) throws UserException;
	
	public String complaintComment(DtoComment dto) throws UserException;
	
	public List<DtoComplaint> getAllComplaints() throws UserException;
	
	public List<DtoCommentRetrieve> getAllComments(int compId) throws UserException;
	
	public String changeStatus(@RequestParam int compId,@RequestParam String status) throws UserException;
	
	public List<DtoComplaint> complaintHistory(String email) throws UserException;
	
	public List<Department> getAllDepartments() throws UserException;
	
	public int forgetPassword(String email) throws MessagingException;
	
	public int verifyOtp(String otp, String email);
	
	public int updatePassword(String pass, String email);
	
	public int changePassword(ChangePasswordDto dto);
	
	public int increaseCount(String email);
	
	public int unblockAccountRequest(String email);
}
