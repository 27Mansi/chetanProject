package com.example.dto;

import java.util.Date;

public class DtoComplaint {
	private int complaintId;
	private int userId;
	private int deptId;
	private String complaintStatus;
	private String userName;
	private String deptHead;
	private String deptName;
	private Date complaintDate;
	private int likeCount;
	private int dislikeCount;
	private String complaintDesc;
	public DtoComplaint() {
		super();
	}
	
	public DtoComplaint(int complaintId, int userId, String userName, String deptName, Date complaintDate,
			int likeCount, int dislikeCount) {
		super();
		this.complaintId = complaintId;
		this.userId = userId;
		this.userName = userName;
		this.deptName = deptName;
		this.complaintDate = complaintDate;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}

	public DtoComplaint(int complaintId, int userId, int deptId,String complaintStatus, String userName, String deptName, Date complaintDate,
			int likeCount, int dislikeCount) {
		super();
		this.complaintId = complaintId;
		this.userId = userId;
		this.deptId = deptId;
		this.complaintStatus = complaintStatus;
		this.userName = userName;
		this.deptName = deptName;
		this.complaintDate = complaintDate;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}
	
	public DtoComplaint(int complaintId, int userId, int deptId,String complaintStatus, String userName, String deptName, Date complaintDate,
			int likeCount, int dislikeCount,String complaintDesc) {
		super();
		this.complaintId = complaintId;
		this.userId = userId;
		this.deptId = deptId;
		this.complaintStatus = complaintStatus;
		this.userName = userName;
		this.deptName = deptName;
		this.complaintDate = complaintDate;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.complaintDesc=complaintDesc;
	}
	
	//For resolved complaints report for admin
	public DtoComplaint(int deptId, String deptName, String deptHead, int complaintId, int userId, String userName,String complaintDesc,
			String complaintStatus, Date complaintDate, int likeCount, int dislikeCount) {
		super();
		this.deptId= deptId;
		this.complaintId = complaintId;
		this.userId=userId;
		this.complaintStatus=complaintStatus;
		this.userName = userName;
		this.deptHead = deptHead;
		this.deptName = deptName;
		this.complaintDate = complaintDate;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.complaintDesc = complaintDesc;
	}
	//for testing purpose
	public DtoComplaint(int complaintId, int userId, int deptId, String complaintStatus, String deptName, int likeCount,
			int dislikeCount, String complaintDesc) {
		super();
		this.complaintId = complaintId;
		this.userId = userId;
		this.deptId = deptId;
		this.complaintStatus = complaintStatus;
		this.deptName = deptName;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.complaintDesc = complaintDesc;
	}

	public String getDeptHead() {
		return deptHead;
	}

	

	public void setDeptHead(String deptHead) {
		this.deptHead = deptHead;
	}

	public int getComplaintId() {
		return complaintId;
	}
	
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public Date getComplaintDate() {
		return complaintDate;
	}
	
	public void setComplaintDate(Date complaintDate) {
		this.complaintDate = complaintDate;
	}
	
	public int getLikeCount() {
		return likeCount;
	}
	
	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}
	
	public int getDislikeCount() {
		return dislikeCount;
	}
	
	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}
	
	public int getDeptId() {
		return deptId;
	}
	
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public String getComplaintDesc() {
		return complaintDesc;
	}

	public void setComplaintDesc(String complaintDesc) {
		this.complaintDesc = complaintDesc;
	}

	@Override
	public String toString() {
		return "DtoComplaint [complaintId=" + complaintId + ", userId=" + userId + ", deptId=" + deptId
				+ ", complaintStatus=" + complaintStatus + ", userName=" + userName + ", deptHead=" + deptHead
				+ ", deptName=" + deptName + ", complaintDate=" + complaintDate + ", likeCount=" + likeCount
				+ ", dislikeCount=" + dislikeCount + ", complaintDesc=" + complaintDesc + "]";
	}

	
	
	
			
}
