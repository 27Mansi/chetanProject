package com.example.dto;

public class UpdateDepartmentDto {
	private int deptId;
	private String deptName;
	private String userName;
	private int userId;
	
	public UpdateDepartmentDto() {
		super();
	}
	public UpdateDepartmentDto(int deptId, String deptName, String userName, int userId) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.userName = userName;
		this.userId = userId;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "UpdateDepartmentDto [deptId=" + deptId + ", deptName=" + deptName + ", userName=" + userName
				+ ", userId=" + userId + "]";
	}	
}
