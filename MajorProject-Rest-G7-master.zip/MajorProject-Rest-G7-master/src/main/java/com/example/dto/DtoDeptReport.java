package com.example.dto;

public class DtoDeptReport {
	private int deptId;
	private String deptName;
	private String deptHead;
	private int totalComplaints;
	private int resolvedComplaints;
	private int pendingComplaints;
	private int reopenedComplaints;
	
	
	public DtoDeptReport(int deptId, String deptName, String deptHead, int totalComplaints, int resolvedComplaints,
			int pendingComplaints, int reopenedComplaints) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.deptHead = deptHead;
		this.totalComplaints = totalComplaints;
		this.resolvedComplaints = resolvedComplaints;
		this.pendingComplaints = pendingComplaints;
		this.reopenedComplaints = reopenedComplaints;
	}
	
	public DtoDeptReport() {
		super();
	}
	
	public int getDeptId() {
		return deptId;
	}
	
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public String getDeptHead() {
		return deptHead;
	}
	
	public void setDeptHead(String deptHead) {
		this.deptHead = deptHead;
	}
	
	public int getTotalComplaints() {
		return totalComplaints;
	}
	
	public void setTotalComplaints(int totalComplaints) {
		this.totalComplaints = totalComplaints;
	}
	
	public int getResolvedComplaints() {
		return resolvedComplaints;
	}
	
	public void setResolvedComplaints(int resolvedComplaints) {
		this.resolvedComplaints = resolvedComplaints;
	}
	
	public int getPendingComplaints() {
		return pendingComplaints;
	}
	
	public void setPendingComplaints(int pendingComplaints) {
		this.pendingComplaints = pendingComplaints;
	}
	
	public int getReopenedComplaints() {
		return reopenedComplaints;
	}
	
	public void setReopenedComplaints(int reopenedComplaints) {
		this.reopenedComplaints = reopenedComplaints;
	}
	
	@Override
	public String toString() {
		return "DtoDeptReport [deptId=" + deptId + ", deptName=" + deptName + ", deptHead=" + deptHead
				+ ", totalComplaints=" + totalComplaints + ", resolvedComplaints=" + resolvedComplaints
				+ ", pendingComplaints=" + pendingComplaints + ", reopenedComplaints=" + reopenedComplaints + "]";
	}		
}
