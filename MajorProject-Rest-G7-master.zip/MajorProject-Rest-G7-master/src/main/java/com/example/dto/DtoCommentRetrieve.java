package com.example.dto;

public class DtoCommentRetrieve {
	private int commentId;
	private String commentDesc;
	private int userId;
	private String userName;
	
	public DtoCommentRetrieve() {
		super();
	}
	
	public DtoCommentRetrieve(int commentId, String commentDesc, int userId, String userName) {
		super();
		this.commentId = commentId;
		this.commentDesc = commentDesc;
		this.userId = userId;
		this.userName = userName;
	}
	
	public int getCommentId() {
		return commentId;
	}
	
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	
	public String getCommentDesc() {
		return commentDesc;
	}
	
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Override
	public String toString() {
		return "DtoCommentRetrieve [commentId=" + commentId + ", commentDesc=" + commentDesc + ", userId=" + userId
				+ ", userName=" + userName + "]";
	}	
}
