package com.example.dto;

public class DtoComplaintRegister {

	private String complaintDesc;
	private String remark;
    private String userEmailDto;
	private int deptId;
	
	public DtoComplaintRegister(String complaintDesc, String remark, String userEmailDto, int deptId) {
		super();
		this.complaintDesc = complaintDesc;
		this.remark = remark;
		this.userEmailDto = userEmailDto;
		this.deptId = deptId;
	}
	
	public String getUserEmailDto() {
		return userEmailDto;
	}

	public void setUserEmailDto(String userEmailDto) {
		this.userEmailDto = userEmailDto;
	}

	public String getComplaintDesc() {
	return complaintDesc;
	}
	
	public void setComplaintDesc(String complaintDesc) {
	this.complaintDesc = complaintDesc;
	}
	
	public String getRemark() {
	return remark;
	}
	
	public void setRemark(String remark) {
	this.remark = remark;
	}
	
	public int getDeptId() {
	return deptId;
	}
	
	public void setDeptId(int deptId) {
	this.deptId = deptId;
	}

	@Override
	public String toString() {
		return "DtoComplaintRegister [complaintDesc=" + complaintDesc + ", remark=" + remark + ", userEmailDto="
				+ userEmailDto + ", deptId=" + deptId + "]";
	}	
}
