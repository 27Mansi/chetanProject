package com.example.dto;

public class DtoComment {
	private String userEmailDto;
	private int complaintIdDto;
	private String descDto;
	
	public DtoComment() {
		super();
	}
	
	public DtoComment(String userEmail, int complaintIdDto, String descDto) {
		super();
		this.userEmailDto = userEmail;
		this.complaintIdDto = complaintIdDto;
		this.descDto = descDto;
	}
	
	public String getUserEmailDto() {
		return userEmailDto;
	}
	
	public void setUserEmailDto(String userEmail) {
		this.userEmailDto = userEmail;
	}
	
	public int getComplaintIdDto() {
		return complaintIdDto;
	}
	
	public void setComplaintIdDto(int complaintIdDto) {
		this.complaintIdDto = complaintIdDto;
	}
	
	public String getDescDto() {
		return descDto;
	}
	
	public void setDescDto(String descDto) {
		this.descDto = descDto;
	}
	
	@Override
	public String toString() {
		return "DtoComment [userEmail=" + userEmailDto + ", complaintIdDto=" + complaintIdDto + ", descDto=" + descDto
				+ "]";
	}	
}
