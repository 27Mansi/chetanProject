package com.example.dto;

public class ChangePasswordDto {
	private String userEmailDto;
	private String currentPass;
	private String newPass;
	
	public ChangePasswordDto() {
		super();
	}
	public ChangePasswordDto(String userEmailDto, String currentPass, String newPass) {
		super();
		this.userEmailDto = userEmailDto;
		this.currentPass = currentPass;
		this.newPass = newPass;
	}
	
	public String getUserEmailDto() {
		return userEmailDto;
	}
	
	public void setUserEmailDto(String userEmailDto) {
		this.userEmailDto = userEmailDto;
	}
	
	public String getCurrentPass() {
		return currentPass;
	}
	
	public void setCurrentPass(String currentPass) {
		this.currentPass = currentPass;
	}
	
	public String getNewPass() {
		return newPass;
	}
	
	public void setNewPass(String newPass) {
		this.newPass = newPass;
	}
	
	@Override
	public String toString() {
		return "ChangePasswordDto [userEmailDto=" + userEmailDto + ", currentPass=" + currentPass + ", newPass="
				+ newPass + "]";
	}		
}
