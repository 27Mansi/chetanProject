package com.example.dto;

public class AddDepartmentDto {
	private int userId;
	private String deptName;
	
	
	public AddDepartmentDto() {
		super();
		
	}
	public AddDepartmentDto(int userId, String deptName) {
		super();
		this.userId = userId;
		this.deptName = deptName;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	@Override
	public String toString() {
		return "AddDepartmentDto [userId=" + userId + ", deptName=" + deptName + "]";
	}	
}
