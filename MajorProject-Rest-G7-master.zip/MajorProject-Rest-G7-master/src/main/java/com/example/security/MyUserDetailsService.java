package com.example.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.example.entity.Users;
import com.example.repository.UsersRepository;
import java.util.*;

@Service(value = "userService")
public class MyUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UsersRepository ur;
	private boolean accountNonLocked;
	
	@SuppressWarnings("unused")
	public UserDetails loadUserByUsername(String userEmail) throws UsernameNotFoundException {
		Users user = ur.findByUserEmail(userEmail);
		accountNonLocked=!user.isAccountLocked();
		if(user.getNoOfLoginAttempts()==2 && accountNonLocked) {
			accountNonLocked=!user.isAccountLocked();
			user.setAccountLocked(true);
			ur.save(user);
		}
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUserEmail(), user.getUserPass(), 
				true,true,true,accountNonLocked,getAuthority(user));
	}

	private Set<SimpleGrantedAuthority> getAuthority(Users user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		
            authorities.add(new SimpleGrantedAuthority("ROLE_" + user.getUserRole()));
		
		return authorities;
	}	   
}